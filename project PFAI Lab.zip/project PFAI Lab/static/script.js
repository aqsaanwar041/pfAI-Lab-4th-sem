// Main client-side script for Real-Time AI Face Filter
const elements = {
  video: document.getElementById('video'),
  canvas: document.getElementById('overlay'),
  toggleCamButton: document.getElementById('toggleCam'),
  filterSelect: document.getElementById('filterSelect')
};

const canvasCtx = elements.canvas.getContext('2d');
let camera = null;
let faceMesh = null;
let isCameraActive = false;

// Load filter images (optional - place in static/images/)
const filters = {
  glasses: { img: new Image(), ready: false, src: '/static/images/glasses.png' },
  mustache: { img: new Image(), ready: false, src: '/static/images/mustache.png' }
};

for (const key of Object.keys(filters)) {
  filters[key].img.onload = () => { filters[key].ready = true; };
  filters[key].img.onerror = () => { filters[key].ready = false; };
  filters[key].img.src = filters[key].src;
}

function initializeFaceMesh() {
  faceMesh = new FaceMesh({
    locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/face_mesh/${file}`
  });

  faceMesh.setOptions({
    maxNumFaces: 1,
    refineLandmarks: true,
    minDetectionConfidence: 0.5,
    minTrackingConfidence: 0.5
  });

  faceMesh.onResults(onResults);
}

function onResults(results) {
  // Resize canvas to match video
  if (!elements.video.videoWidth) return;
  elements.canvas.width = elements.video.videoWidth;
  elements.canvas.height = elements.video.videoHeight;

  canvasCtx.save();
  canvasCtx.clearRect(0, 0, elements.canvas.width, elements.canvas.height);

  // Draw camera frame
  canvasCtx.drawImage(results.image, 0, 0, elements.canvas.width, elements.canvas.height);

  if (results.multiFaceLandmarks && results.multiFaceLandmarks.length > 0) {
    const landmarks = results.multiFaceLandmarks[0];
    const selected = elements.filterSelect.value;

    if (selected === 'glasses') {
      const left = landmarks[33];
      const right = landmarks[263];
      const centerX = (left.x + right.x) / 2 * elements.canvas.width;
      const centerY = (left.y + right.y) / 2 * elements.canvas.height;
      const width = Math.hypot((right.x - left.x) * elements.canvas.width, (right.y - left.y) * elements.canvas.height) * 2.2;
      const height = width * 0.45;

      if (filters.glasses.ready) {
        canvasCtx.drawImage(filters.glasses.img, centerX - width / 2, centerY - height / 2, width, height);
      } else {
        // fallback simple rectangle
        canvasCtx.fillStyle = 'rgba(0,0,0,0.6)';
        canvasCtx.fillRect(centerX - width / 2, centerY - height / 2, width, height);
      }
    }

    if (selected === 'mustache') {
      const leftM = landmarks[61];
      const rightM = landmarks[291];
      const top = landmarks[13];
      const centerX = (leftM.x + rightM.x) / 2 * elements.canvas.width;
      const centerY = top.y * elements.canvas.height + ((leftM.y + rightM.y) / 2 - top.y) * elements.canvas.height * 0.4;
      const width = Math.hypot((rightM.x - leftM.x) * elements.canvas.width, (rightM.y - leftM.y) * elements.canvas.height) * 1.3;
      const height = width * 0.25;

      if (filters.mustache.ready) {
        canvasCtx.drawImage(filters.mustache.img, centerX - width / 2, centerY - height / 2, width, height);
      } else {
        canvasCtx.fillStyle = 'sienna';
        canvasCtx.fillRect(centerX - width / 2, centerY - height / 2, width, height);
      }
    }
  }

  canvasCtx.restore();
}

async function startCamera() {
  if (isCameraActive) return;
  if (!faceMesh) initializeFaceMesh();

  camera = new Camera(elements.video, {
    onFrame: async () => { await faceMesh.send({image: elements.video}); },
    width: 640,
    height: 480
  });

  try {
    await camera.start();
    isCameraActive = true;
    elements.toggleCamButton.textContent = 'Stop Camera';
  } catch (err) {
    console.error('Camera start failed', err);
    alert('Unable to start camera. Check permissions and that no other app is using it.');
  }
}

async function stopCamera() {
  if (!isCameraActive) return;
  if (camera && camera.stop) {
    try { camera.stop(); } catch (e) { console.warn('camera.stop() error', e); }
  }
  // clear canvas and pause video
  canvasCtx.clearRect(0, 0, elements.canvas.width, elements.canvas.height);
  elements.video.pause();
  isCameraActive = false;
  elements.toggleCamButton.textContent = 'Start Camera';
}

// Toggle button
elements.toggleCamButton.addEventListener('click', () => {
  if (!isCameraActive) startCamera(); else stopCamera();
});

// Initialize on load
initializeFaceMesh();

// Make sure canvas covers video when layout changes
window.addEventListener('resize', () => {
  if (elements.video.videoWidth) {
    elements.canvas.width = elements.video.videoWidth;
    elements.canvas.height = elements.video.videoHeight;
  }
});
